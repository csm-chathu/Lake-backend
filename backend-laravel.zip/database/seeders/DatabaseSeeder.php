<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\ClinicSetting;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            UserSeeder::class,
        ]);

        ClinicSetting::firstOrCreate(
            [],
            [
                'name' => 'THE LAKE ANIMAL CLINIC',
                'phone' => '071 730 7641',
                'email' => null,
                'address' => 'Wewa Rd, Anuradhapura',
                'timezone' => config('app.timezone'),
                'currency_code' => 'LKR',
                'logo_url' => 'tr-logo.png',
                'sms_sender_id' => config('sms.sender_id')
            ]
        );
    }
}
