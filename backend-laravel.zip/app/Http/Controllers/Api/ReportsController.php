<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Models\DirectSale;
use App\Models\Patient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportsController extends Controller
{
    /**
     * Get comprehensive report data for a date range
     * Query params: startDate (ISO date), endDate (ISO date)
     */
    public function getComprehensiveReport(Request $request)
    {
        $data = $request->validate([
            'startDate' => 'required|date_format:Y-m-d',
            'endDate' => 'required|date_format:Y-m-d|after_or_equal:startDate'
        ]);

        $startDate = $data['startDate'] . ' 00:00:00';
        $endDate = $data['endDate'] . ' 23:59:59';

        // Get revenue data
        $appointmentRevenue = Appointment::whereBetween('date', [$startDate, $endDate])
            ->select(DB::raw('COALESCE(SUM(COALESCE(total_charge, 0)), 0) as total'))
            ->value('total') ?? 0;

        $salesRevenue = DirectSale::whereBetween('date', [$startDate, $endDate])
            ->select(DB::raw('COALESCE(SUM(total), 0) as total'))
            ->value('total') ?? 0;

        // Total appointments in period
        $totalAppointments = Appointment::whereBetween('date', [$startDate, $endDate])->count();

        // Total direct sales
        $totalSales = DirectSale::whereBetween('date', [$startDate, $endDate])->count();

        // Unique patients visited
        $totalPatients = Appointment::whereBetween('date', [$startDate, $endDate])
            ->distinct('patient_id')
            ->count();

        // Gender distribution of patients in appointments
        $genderData = Appointment::whereBetween('appointments.date', [$startDate, $endDate])
            ->join('patients', 'appointments.patient_id', '=', 'patients.id')
            ->select('patients.gender', DB::raw('COUNT(*) as count'))
            ->whereNotNull('patients.gender')
            ->groupBy('patients.gender')
            ->get();

        $maleCount = 0;
        $femaleCount = 0;
        
        foreach ($genderData as $row) {
            if (strtolower($row->gender) === 'male') {
                $maleCount = (int) $row->count;
            } elseif (strtolower($row->gender) === 'female') {
                $femaleCount = (int) $row->count;
            }
        }

        // Top 5 most common reasons
        $commonReasons = Appointment::whereBetween('date', [$startDate, $endDate])
            ->select('reason', DB::raw('COUNT(*) as count'))
            ->groupBy('reason')
            ->orderByDesc('count')
            ->limit(5)
            ->get()
            ->map(function ($item) {
                return [
                    'reason' => $item->reason,
                    'count' => $item->count
                ];
            })
            ->toArray();

        // Most visited patients (top 10)
        $mostVisitedPatients = Appointment::whereBetween('appointments.date', [$startDate, $endDate])
            ->join('patients', 'appointments.patient_id', '=', 'patients.id')
            ->leftJoin('owners', 'patients.owner_id', '=', 'owners.id')
            ->select(
                'patients.id',
                'patients.name',
                DB::raw("COALESCE(owners.first_name, '') || ' ' || COALESCE(owners.last_name, '') as ownerName"),
                DB::raw('COUNT(appointments.id) as visitCount'),
                DB::raw('COALESCE(SUM(appointments.total_charge), 0) as totalRevenue')
            )
            ->groupBy('patients.id', 'patients.name')
            ->orderByDesc('visitCount')
            ->limit(10)
            ->get()
            ->map(function ($item) {
                return [
                    'id' => $item->id,
                    'name' => $item->name,
                    'ownerName' => trim($item->ownerName),
                    'visitCount' => $item->visitCount,
                    'totalRevenue' => (float) $item->totalRevenue
                ];
            })
            ->toArray();

        return response()->json([
            'appointmentRevenue' => round((float)$appointmentRevenue, 2),
            'salesRevenue' => round((float)$salesRevenue, 2),
            'totalRevenue' => round((float)$appointmentRevenue + (float)$salesRevenue, 2),
            'totalAppointments' => $totalAppointments,
            'totalSales' => $totalSales,
            'totalPatients' => $totalPatients,
            'maleCount' => $maleCount,
            'femaleCount' => $femaleCount,
            'commonReasons' => $commonReasons,
            'mostVisitedPatients' => $mostVisitedPatients,
            'period' => [
                'startDate' => $data['startDate'],
                'endDate' => $data['endDate']
            ]
        ]);
    }
}
