<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClinicSetting extends Model
{
    use HasFactory;

    protected $table = 'clinic_settings';

    protected $fillable = [
        'name',
        'phone',
        'email',
        'address',
        'timezone',
        'currency_code',
        'logo_url',
        'sms_sender_id',
    ];
}
